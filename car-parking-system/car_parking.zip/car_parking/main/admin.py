from django.contrib import admin
from main.models import addvehicle
# Register your models here.
admin.site.register(addvehicle)